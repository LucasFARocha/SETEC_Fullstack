import { useState } from 'react'
import './styles.css'
import TodoList from '../TodoList/TodoList'

function App() {
  return (
    <>
      <TodoList />
    </>
  )
}

export default App
