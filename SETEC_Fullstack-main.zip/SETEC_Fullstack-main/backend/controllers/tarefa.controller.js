import Tarefa from '../models/tarefa.model.js'

// Create a new Tarefa
export const createTarefa = async (req, res) => {
    try{
        const { text } = req.body // retire a propriedade text do body
        const newTarefa = new Tarefa({ text })
        const savedTarefa = await newTarefa.save()
        res.status(201).json(savedTarefa)
    } catch(error) {
        res.status(500).json({ message: error.message })
    }
}

// Get all Tarefas
export const getTarefas = async (req, res) => {
    try{
        const tarefas = await Tarefa.find().sort({ createdAt: -1 })
        res.json(tarefas)
    } catch(error) {
        res.status(500).json({ message: error.message })
    }
}

// Update a Tarefa
export const updateTarefa = async (req, res) => {
    try{
        const { id } = req.params
        const { text, isCompleted } = req.body
        const updatedTarefa = await Tarefa.findByIdAndUpdate(
            id,
            { text, isCompleted },
            { new: true }
        )
        if(!updatedTarefa){
            return res.status(404).json({ message: 'Tarefa não encontrada' })
        }
        res.json(updatedTarefa)
    } catch(error) {
        res.status(500).json({ message: error.message })
    }
}

// Delete a Tarefa
export const deleteTarefa = async (req, res) => {
    try{
        const { id } = req.params
        const deletedTarefa = await Tarefa.findByIdAndDelete(id)
        if(!deletedTarefa){
            return res.status(404).json({ message: 'Tarefa não encontrada' })
        }
        res.json({ message: 'Tarefa excluída com sucesso' })
    } catch(error) {
        res.status(500).json({ message: error.message })
    }
}

// Delete all Tarefas
export const deleteAllTarefas = async (req, res) => {
    try{
        await Tarefa.deleteMany({})
        res.json({ message: 'Todas as tarefas excluídas com sucesso' })
    } catch(error) {
        res.status(500).json({ message: error.message })
    }
}