import mongoose from "mongoose"

const TarefaSchema = new mongoose.Schema(
{
    text: {
        type: String,
        required: true,
    },
    isCompleted: {
        type: Boolean,
        default: false,
    },
}, 
{
    timestamps: true,
})

const Tarefa = mongoose.model('Tarefa', TarefaSchema)
export default Tarefa