import express from 'express'
import {
    createTarefa,
    getTarefas,
    updateTarefa,
    deleteTarefa,
    deleteAllTarefas,
} from '../controllers/tarefa.controller.js'

const router = express.Router()

router.post('/tarefas', createTarefa)
router.get('/tarefas', getTarefas)
router.put('/tarefas/:id', updateTarefa)
router.delete('/tarefas/:id', deleteTarefa)
router.delete('/tarefas', deleteAllTarefas)

export default router